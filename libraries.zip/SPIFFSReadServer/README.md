# SPIFFSReadServer
An SPI Flash File System (SPIFFS) server extension of the ESP8266WebServer library. This is intended to handle 'read-only' static files without the need for a live editor. Of course files can still be modified programmatically or via other server handlers.

[Full Documentation](http://ryandowning.net/SPIFFSReadServer)
